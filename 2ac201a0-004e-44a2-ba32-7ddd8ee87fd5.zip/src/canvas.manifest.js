export const manifest = {
  screens: {
    scr_5w5s8d: { name: "Production Cockpit", route: "/" }
  }
};