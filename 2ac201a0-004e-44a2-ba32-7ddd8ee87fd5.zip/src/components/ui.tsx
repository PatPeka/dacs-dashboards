import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
export function Card({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        'bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden',
        className
      )}
      {...props}>
      
      {children}
    </div>);

}
export function CardHeader({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn('px-6 py-4 border-b border-slate-100', className)}
      {...props}>
      
      {children}
    </div>);

}
export function CardTitle({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3
      className={cn('text-lg font-semibold text-slate-900', className)}
      {...props}>
      
      {children}
    </h3>);

}
export function CardContent({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('px-6 py-4', className)} {...props}>
      {children}
    </div>);

}
interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'outline';
}
export function Badge({
  className,
  variant = 'default',
  children,
  ...props
}: BadgeProps) {
  const variants = {
    default: 'bg-slate-100 text-slate-800',
    success: 'bg-emerald-100 text-emerald-800',
    warning: 'bg-amber-100 text-amber-800',
    danger: 'bg-orange-100 text-orange-800',
    info: 'bg-blue-100 text-blue-800',
    outline: 'bg-transparent border border-slate-200 text-slate-600'
  };
  return (
    <span
      className={cn(
        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
        variants[variant],
        className
      )}
      {...props}>
      
      {children}
    </span>);

}
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}
export function Button({
  className,
  variant = 'primary',
  size = 'md',
  children,
  ...props
}: ButtonProps) {
  const variants = {
    primary:
    'bg-blue-600 text-white hover:bg-blue-700 shadow-sm border border-transparent',
    secondary:
    'bg-teal-600 text-white hover:bg-teal-700 shadow-sm border border-transparent',
    outline:
    'bg-white text-slate-700 hover:bg-slate-50 border border-slate-300 shadow-sm',
    ghost:
    'bg-transparent text-slate-600 hover:bg-slate-100 hover:text-slate-900'
  };
  const sizes = {
    sm: 'px-3 py-1.5 text-xs',
    md: 'px-4 py-2 text-sm',
    lg: 'px-6 py-3 text-base'
  };
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center font-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors',
        variants[variant],
        sizes[size],
        className
      )}
      {...props}>
      
      {children}
    </button>);

}
export function ProgressBar({
  value,
  max = 100,
  className,
  colorClass = 'bg-blue-600'





}: {value: number;max?: number;className?: string;colorClass?: string;}) {
  const percentage = Math.min(100, Math.max(0, value / max * 100));
  return (
    <div
      className={cn(
        'w-full bg-slate-100 rounded-full h-2 overflow-hidden',
        className
      )}>
      
      <div
        className={cn(
          'h-full rounded-full transition-all duration-500',
          colorClass
        )}
        style={{
          width: `${percentage}%`
        }} />
      
    </div>);

}