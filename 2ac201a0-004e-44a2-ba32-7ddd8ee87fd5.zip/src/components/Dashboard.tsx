import React from 'react';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Clock,
  Info,
  MapPin,
  Play,
  RefreshCw,
  SkipForward,
  Users } from
'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Badge,
  Button,
  ProgressBar,
  cn } from
'./ui';
export function Dashboard() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-blue-100">
      {/* Top Navigation */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-[1600px] mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center text-white font-bold text-xl">
                D
              </div>
              <span className="font-bold text-xl tracking-tight text-slate-800">
                DACS
              </span>
            </div>
            <div className="h-5 w-px bg-slate-300 mx-1"></div>
            <Badge
              variant="info"
              className="text-sm px-3 py-1 bg-blue-50 text-blue-700 border border-blue-100">
              
              Assist
            </Badge>
          </div>

          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2 text-slate-600">
              <Clock className="w-4 h-4" />
              <span>Wednesday, 24 June 2026</span>
            </div>
            <div className="flex items-center gap-2 text-slate-600">
              <MapPin className="w-4 h-4" />
              <span className="font-medium text-slate-800">
                CHU Liège — Central Pharmacy
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="font-medium text-slate-800">
                Live production
              </span>
            </div>
            <Badge
              variant="outline"
              className="flex items-center gap-1.5 text-slate-500">
              
              <RefreshCw className="w-3 h-3" />
              Data updated 08:55
            </Badge>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-6 py-8 space-y-6">
        {/* Title Section */}
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            Daily Production Cockpit
          </h1>
          <p className="text-slate-500 mt-1">
            Risk-aware ward sequencing for live patient-specific dispensing
          </p>
        </div>

        {/* KPI Row */}
        <div className="grid grid-cols-5 gap-4">
          <Card>
            <CardContent className="p-5">
              <div className="text-sm font-medium text-slate-500 mb-1">
                Daily objective
              </div>
              <div className="flex items-baseline gap-2 mb-3">
                <span className="text-2xl font-bold text-slate-900">0</span>
                <span className="text-sm font-medium text-slate-400">
                  / 5,690
                </span>
              </div>
              <div className="flex items-center gap-3">
                <ProgressBar value={0} className="flex-1" />
                <span className="text-xs font-medium text-slate-500 w-8 text-right">
                  0%
                </span>
              </div>
              <div className="text-xs text-slate-400 mt-2">Doses produced</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="text-sm font-medium text-slate-500 mb-1">
                Patients remaining
              </div>
              <div className="flex items-baseline gap-2 mb-3">
                <span className="text-2xl font-bold text-slate-900">0</span>
                <span className="text-sm font-medium text-slate-400">
                  / 596
                </span>
              </div>
              <div className="flex items-center gap-3">
                <ProgressBar
                  value={0}
                  className="flex-1"
                  colorClass="bg-teal-500" />
                
                <span className="text-xs font-medium text-slate-500 w-8 text-right">
                  0%
                </span>
              </div>
              <div className="text-xs text-slate-400 mt-2">Patients served</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5 flex flex-col justify-center h-full">
              <div className="text-sm font-medium text-slate-500 mb-1">
                Start time
              </div>
              <div className="text-2xl font-bold text-slate-900">09:02</div>
              <div className="text-xs text-slate-400 mt-2">
                Production started
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5 flex flex-col justify-center h-full">
              <div className="text-sm font-medium text-slate-500 mb-1">
                Cut-off
              </div>
              <div className="text-2xl font-bold text-slate-900">18:00</div>
              <div className="text-xs text-slate-400 mt-2">Target end</div>
            </CardContent>
          </Card>

          <Card className="border-emerald-200 bg-emerald-50/30">
            <CardContent className="p-5 flex flex-col justify-center h-full">
              <div className="flex items-center justify-between mb-1">
                <div className="text-sm font-medium text-slate-500">
                  Forecast end
                </div>
                <Badge
                  variant="success"
                  className="bg-emerald-100 text-emerald-700 border border-emerald-200">
                  
                  On track
                </Badge>
              </div>
              <div className="text-2xl font-bold text-slate-900">13:46</div>
              <div className="text-xs font-medium text-emerald-600 mt-2 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                04h44 remaining
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-12 gap-6">
          {/* Left/Center Column (9 cols) */}
          <div className="col-span-9 space-y-6">
            {/* Main Recommendation Card */}
            <Card className="border-blue-200 shadow-md shadow-blue-900/5 relative overflow-visible">
              <div className="absolute top-0 left-0 w-1.5 h-full bg-blue-600 rounded-l-xl"></div>
              <CardContent className="p-8">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Activity className="w-5 h-5 text-blue-600" />
                      <h2 className="text-sm font-bold uppercase tracking-wider text-blue-600">
                        Next Recommended Ward
                      </h2>
                    </div>
                    <h3 className="text-3xl font-bold text-slate-900 mt-2 mb-6">
                      248 — Revalidation Neuro-Locom
                    </h3>

                    <div className="flex items-center gap-8 mb-6">
                      <div>
                        <div className="text-sm text-slate-500 mb-1">
                          Patients
                        </div>
                        <div className="text-xl font-semibold text-slate-800 flex items-center gap-2">
                          <Users className="w-5 h-5 text-slate-400" />
                          32
                        </div>
                      </div>
                      <div className="w-px h-10 bg-slate-200"></div>
                      <div>
                        <div className="text-sm text-slate-500 mb-1">Doses</div>
                        <div className="text-xl font-semibold text-slate-800">
                          357
                        </div>
                      </div>
                      <div className="w-px h-10 bg-slate-200"></div>
                      <div>
                        <div className="text-sm text-slate-500 mb-1">
                          Median RCP
                        </div>
                        <div className="text-xl font-semibold text-slate-800">
                          0.05
                        </div>
                      </div>
                      <div className="w-px h-10 bg-slate-200"></div>
                      <div>
                        <div className="text-sm text-slate-500 mb-1">
                          Est. duration
                        </div>
                        <div className="text-xl font-semibold text-slate-800 flex items-center gap-2">
                          <Clock className="w-5 h-5 text-slate-400" />
                          35 min
                        </div>
                      </div>
                      <div className="w-px h-10 bg-slate-200"></div>
                      <div>
                        <div className="text-sm text-slate-500 mb-1">
                          Progress
                        </div>
                        <div className="text-xl font-semibold text-slate-800">
                          0%
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 rounded-lg p-4 flex items-start gap-3 mb-8 border border-blue-100">
                      <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                      <p className="text-sm text-blue-900 leading-relaxed">
                        <span className="font-semibold">
                          Recommended because:
                        </span>{' '}
                        This ward combines low return risk and high remaining
                        workload.
                      </p>
                    </div>

                    <div className="flex items-center gap-4">
                      <Button
                        size="lg"
                        className="gap-2 shadow-blue-600/20 shadow-lg">
                        
                        <Play className="w-5 h-5 fill-current" />
                        Start production
                      </Button>
                      <Button variant="outline" size="lg" className="gap-2">
                        <SkipForward className="w-5 h-5" />
                        Skip recommendation
                      </Button>
                    </div>

                    <p className="text-xs text-slate-500 mt-4 flex items-center gap-1.5">
                      <RefreshCw className="w-3.5 h-3.5" />
                      DACS adapts the next recommendation based on real
                      production progress.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Ranked Ward Table */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-4">
                <CardTitle>Recommended production sequence by ward</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                  
                  View full schedule <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </CardHeader>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-y border-slate-200">
                    <tr>
                      <th className="px-6 py-3 font-medium">Rank</th>
                      <th className="px-6 py-3 font-medium">Ward</th>
                      <th className="px-6 py-3 font-medium text-right">
                        Patients
                      </th>
                      <th className="px-6 py-3 font-medium text-right">
                        Doses
                      </th>
                      <th className="px-6 py-3 font-medium text-right">
                        Median RCP
                      </th>
                      <th className="px-6 py-3 font-medium text-right">
                        Est. duration
                      </th>
                      <th className="px-6 py-3 font-medium">Progress</th>
                      <th className="px-6 py-3 font-medium text-right">
                        SLA risk
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {[
                    {
                      rank: 1,
                      ward: '248 — Revalidation Neuro-Locom',
                      patients: 32,
                      doses: 357,
                      rcp: '0.05',
                      duration: '35 min',
                      progress: 0,
                      risk: 'On track',
                      riskType: 'success'
                    },
                    {
                      rank: 2,
                      ward: '236 — Pneumo Cardio Rxthér.',
                      patients: 28,
                      doses: 312,
                      rcp: '0.09',
                      duration: '31 min',
                      progress: 0,
                      risk: 'On track',
                      riskType: 'success'
                    },
                    {
                      rank: 3,
                      ward: '443 — 3CD Oncologie',
                      patients: 28,
                      doses: 202,
                      rcp: '0.09',
                      duration: '20 min',
                      progress: 0,
                      risk: 'On track',
                      riskType: 'success'
                    },
                    {
                      rank: 4,
                      ward: '224 — Néphrologie / Médecine interne',
                      patients: 25,
                      doses: 315,
                      rcp: '0.10',
                      duration: '31 min',
                      progress: 0,
                      risk: 'Watch',
                      riskType: 'warning'
                    },
                    {
                      rank: 5,
                      ward: '159 — Gériatrie 2',
                      patients: 26,
                      doses: 225,
                      rcp: '0.11',
                      duration: '22 min',
                      progress: 0,
                      risk: 'Watch',
                      riskType: 'warning'
                    },
                    {
                      rank: 6,
                      ward: '135 — Médecine A',
                      patients: 18,
                      doses: 154,
                      rcp: '0.11',
                      duration: '15 min',
                      progress: 0,
                      risk: 'On track',
                      riskType: 'success'
                    },
                    {
                      rank: 7,
                      ward: '225 — Médecine Interne',
                      patients: 25,
                      doses: 246,
                      rcp: '0.11',
                      duration: '24 min',
                      progress: 0,
                      risk: 'On track',
                      riskType: 'success'
                    },
                    {
                      rank: 8,
                      ward: '227 — Neurologie / Neurochir.',
                      patients: 30,
                      doses: 239,
                      rcp: '0.12',
                      duration: '23 min',
                      progress: 0,
                      risk: 'Delay risk',
                      riskType: 'danger'
                    }].
                    map((row, i) =>
                    <tr
                      key={i}
                      className={cn(
                        'hover:bg-slate-50/50 transition-colors',
                        i === 0 ? 'bg-blue-50/30' : ''
                      )}>
                      
                        <td className="px-6 py-4 font-medium text-slate-900">
                          <div
                          className={cn(
                            'w-6 h-6 rounded-full flex items-center justify-center text-xs',
                            i === 0 ?
                            'bg-blue-600 text-white' :
                            'bg-slate-100 text-slate-600'
                          )}>
                          
                            {row.rank}
                          </div>
                        </td>
                        <td
                        className={cn(
                          'px-6 py-4 font-medium',
                          i === 0 ? 'text-blue-900' : 'text-slate-900'
                        )}>
                        
                          {row.ward}
                        </td>
                        <td className="px-6 py-4 text-right text-slate-600">
                          {row.patients}
                        </td>
                        <td className="px-6 py-4 text-right text-slate-600">
                          {row.doses}
                        </td>
                        <td className="px-6 py-4 text-right font-medium text-slate-700">
                          {row.rcp}
                        </td>
                        <td className="px-6 py-4 text-right text-slate-600">
                          {row.duration}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <ProgressBar
                            value={row.progress}
                            className="w-16" />
                          
                            <span className="text-xs text-slate-500">
                              {row.progress}%
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <Badge variant={row.riskType as any}>
                            {row.risk}
                          </Badge>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>

          {/* Right Column (3 cols) */}
          <div className="col-span-3 space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-600" />
                  Why this sequence?
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <ul className="space-y-3">
                  {[
                  'Lower median RCP first',
                  'Remaining workload included',
                  'Fixed production rate applied',
                  'Recalculated as production progresses'].
                  map((item, i) =>
                  <li
                    key={i}
                    className="flex items-start gap-2.5 text-sm text-slate-600">
                    
                      <CheckCircle2 className="w-4 h-4 text-teal-500 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  )}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="w-4 h-4 text-blue-600" />
                  SLA forecast
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                    <span className="text-sm text-slate-500">
                      Estimated completion
                    </span>
                    <span className="text-sm font-semibold text-slate-900">
                      13:46
                    </span>
                  </div>
                  <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                    <span className="text-sm text-slate-500">Cut-off</span>
                    <span className="text-sm font-semibold text-slate-900">
                      18:00
                    </span>
                  </div>
                  <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                    <span className="text-sm text-slate-500">Buffer</span>
                    <span className="text-sm font-semibold text-emerald-600">
                      04h14
                    </span>
                  </div>
                  <div className="pt-1">
                    <Badge
                      variant="success"
                      className="w-full justify-center py-1.5 text-sm">
                      
                      On track
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-orange-500" />
                  Exceptions to monitor
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-2.5 rounded-lg bg-orange-50 border border-orange-100">
                    <div className="w-6 h-6 rounded bg-orange-100 text-orange-700 flex items-center justify-center text-xs font-bold shrink-0">
                      12
                    </div>
                    <div className="text-sm text-orange-900 mt-0.5">
                      DO received late
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="w-6 h-6 rounded bg-slate-200 text-slate-700 flex items-center justify-center text-xs font-bold shrink-0">
                      4
                    </div>
                    <div className="text-sm text-slate-700 mt-0.5">
                      DO cancelled by ADT
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-2.5 rounded-lg bg-amber-50 border border-amber-100">
                    <div className="w-6 h-6 rounded bg-amber-100 text-amber-700 flex items-center justify-center text-xs font-bold shrink-0">
                      8
                    </div>
                    <div className="text-sm text-amber-900 mt-0.5">
                      DO waiting for RCP
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-2.5 rounded-lg bg-emerald-50 border border-emerald-100">
                    <div className="w-6 h-6 rounded bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs font-bold shrink-0">
                      0
                    </div>
                    <div className="text-sm text-emerald-900 mt-0.5">
                      robot capacity alerts
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-8 pt-6 border-t border-slate-200">
          <div className="max-w-3xl mx-auto">
            {/* Mini Timeline */}
            <div className="relative mb-8">
              <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 -translate-y-1/2"></div>
              <div className="absolute top-1/2 left-0 w-[45%] h-0.5 bg-emerald-500 -translate-y-1/2"></div>

              <div className="relative flex justify-between items-center">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-emerald-500 border-4 border-white shadow-sm z-10"></div>
                  <div className="text-center">
                    <div className="text-sm font-bold text-slate-900">
                      09:02
                    </div>
                    <div className="text-xs text-slate-500">Start</div>
                  </div>
                </div>

                <div className="flex flex-col items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-white border-4 border-emerald-500 shadow-sm z-10"></div>
                  <div className="text-center">
                    <div className="text-sm font-bold text-slate-900">
                      13:46
                    </div>
                    <div className="text-xs text-emerald-600 font-medium">
                      Forecast end
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-white border-4 border-slate-300 shadow-sm z-10"></div>
                  <div className="text-center">
                    <div className="text-sm font-bold text-slate-900">
                      18:00
                    </div>
                    <div className="text-xs text-slate-500">Cut-off</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Operational Notes */}
            <div className="flex items-center justify-center gap-8 text-sm text-slate-500">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-slate-400" />
                <span>
                  <strong className="text-slate-700">Human-in-the-loop:</strong>{' '}
                  operator can follow or override.
                </span>
              </div>
              <div className="w-1 h-1 rounded-full bg-slate-300"></div>
              <div className="flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-slate-400" />
                <span>
                  <strong className="text-slate-700">Live adaptation:</strong>{' '}
                  recommendations update based on real production.
                </span>
              </div>
              <div className="w-1 h-1 rounded-full bg-slate-300"></div>
              <div className="flex items-center gap-2">
                <ArrowRight className="w-4 h-4 text-slate-400" />
                <span>
                  <strong className="text-slate-700">Next step:</strong> SLA
                  alerts and delivery tracking.
                </span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>);

}